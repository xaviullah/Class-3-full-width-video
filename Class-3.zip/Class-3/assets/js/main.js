(function ($) {
	"use strict";

    jQuery(document).ready(function($){
     $(".video-play-btn").magnificPopup({
		 type:'video',
	 })


        


    });


    jQuery(window).load(function(){

        
    });


}(jQuery));	